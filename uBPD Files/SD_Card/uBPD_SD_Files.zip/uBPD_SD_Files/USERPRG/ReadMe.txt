User created utility programs for the Backpack drive

DNLOAD.BA - Allows reading a BASIC program which has been saved as a .DO into memory and tokenizing it one line a time. This makes it much easier to tokenize large programs as you don't need both the .DO and .BA versions in memory at the same time.

RTC.BA - Sets the M100/102/200 clock from the RTC on the Backpack.
RTCNEC-BA - Sets the NEC 8201A, etc. clock from the RTC on the Backpack.

by Georg Käter -  sets RTC compensating for time/date format differences
RTCSET.DO.FULL -  (remove .FULL / .SMALL extension)
RTCSET.DO.SMALL - (remove .FULL / .SMALL extension)