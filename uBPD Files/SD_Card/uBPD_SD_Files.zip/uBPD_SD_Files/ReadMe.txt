What are all of these files and folder for?

Manuals - Users' manuals for Backpack, Backpack+, and TS-DOS Quick Reference

SECTOR0 - System files for TRS-80 Model 100 (M100) type computers
TEST01 - Test folder for M100 computers to show TS-DOS can use folders
USERPRG - M100 programs users created that leverage the Backpack's capabilities
BPDP3000.bin - Firmware for Backpack when used for M100
HEY.BA - A very simple M100 test program to demonstrate loading a file

pf10 - Epson PF-10 disk drive emulation files
sector2 - Epson PX-8, HX-20 (Epson) system files
tf20 - Epson TF-20 disk drive emulation files
EBPD3000.bin - Firmware for Backpack when used for Epson

If you are using this Backpack for only one system you can delete the 
other system's files from this card.